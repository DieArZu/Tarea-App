/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package expenses.database.module;

import expenses.models.module.User;
import expenses.models.module.contacto;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Samuel
 */
public class databaseHelper {

    Connection conn;

    public databaseHelper() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/agendatelefonica", "root", "Admin$1234");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(databaseHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    
    public boolean validateLogin(String txtusuario, String txtPwd) throws SQLException {
        Statement statement = conn.createStatement();
        String sql = "SELECT * FROM agendatelefonica.users WHERE Name = '" + txtusuario + "' AND pwd = '" + txtPwd + "'";
        ResultSet resultset = statement.executeQuery(sql);
        while (resultset.next()) {
            return true;
        }
        return false;
    }

    public ResultSet getExpenses(int idUser) throws SQLException {
        Statement statement = conn.createStatement();
        String sql = "SELECT * FROM agendatelefonica.contactos;";
        ResultSet resultset = statement.executeQuery(sql);
        return resultset;
    }
    
    public void printAllContacts() {
    try {
        ResultSet resultset = getExpenses(0); // Llama al método (el parámetro no se usa en este caso)

        // Iterar a través del ResultSet
        while (resultset.next()) {
            int id = resultset.getInt("id");
            String nombre = resultset.getString("nombre");
            String telefono = resultset.getString("telefono");
            String email = resultset.getString("email");
            String direccion = resultset.getString("direccion");

            /* Imprimir los datos en la consola
            System.out.println("ID: " + id + ", Nombre: " + nombre + ", Teléfono: " + telefono + 
                               ", Email: " + email + ", Dirección: " + direccion);*/
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    
 

    
    
    }

    /*
    public User getUser(String email) throws SQLException {
        Statement statement = conn.createStatement();
        String sql = "SELECT * FROM expensesdatabase.users WHERE email = '" + email + "'";
        ResultSet resultset = statement.executeQuery(sql);
        while (resultset.next()) {
            User user = new User(
                    resultset.getInt("id"),
                    resultset.getString("lastname"),
                    resultset.getString("firstname"),
                    resultset.getString("email")
            );

            return user;
        }

        return null;
    }
}
*/