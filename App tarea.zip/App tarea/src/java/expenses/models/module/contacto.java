/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package expenses.models.module;

/**
 *
 * @author Samuel
 */
public class contacto {
    
    public String nombre;
    public String telefono;
    public String email;  
    public String direccion;  
    
    public contacto (
                String _nombre,
                String _telefono,
                String _email,
                String _direccion
    )
 
    {
        this.nombre = _nombre;
        this.telefono = _telefono;
        this.email = _email;        
        this.direccion = _direccion;     
    }
}
